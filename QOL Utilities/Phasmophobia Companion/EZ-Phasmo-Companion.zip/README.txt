EZ PHASMO COMPANION — NO SOUND BUILD

Install: Back up the existing files in C:\Users\JayAppell\Phas. Copy
index.html, script.js and style.css into that folder, replacing the old
ones, and DELETE sound-analyzer.js (it is no longer used).
Restart the server if needed and press Ctrl+F5 in Edge.

What changed:
- All sound features are removed: the Ghost Sound Analyzer, footstep
  calibration, audio-based eliminations, voice commands (microphone),
  spoken announcements, and the Settings window (it only held voice options).
- The app never asks for microphone, screen-sharing or audio access.
- The separate Candidates panel is removed; the remaining count is shown
  next to the GHOST CANDIDATES heading.

Still included: evidence, behavioral clues, manual ghost exclusion,
ghost details, and the master grid.

Optional cleanup: older versions saved voice and calibration settings in
the browser's storage. They are unused and harmless.
