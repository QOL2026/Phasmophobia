const evidenceOptions = [
  'EMF Level 5',
  'Spirit Box',
  'Ghost Writing',
  'Ghost Orb',
  'D.O.T.S Projector',
  'Ultraviolet',
  'Freezing Temperatures',
];

const evidenceDescriptions = {
  'EMF Level 5': 'Get a level 5 reading on the EMF Reader.',
  'D.O.T.S Projector': 'Witness a ghostly disturbance within D.O.T.S Projector lights.',
  Ultraviolet: 'Uncover finger, hand, or footprints with the UV Light.',
  'Freezing Temperatures': 'Get a reading below 0Â°C / 32Â°F on a Thermometer.',
  'Ghost Orb': 'See floating orbs on video through a Video Camera, Video Feed, or Head Gear.',
  'Ghost Writing': 'Have a ghost write in a Ghost Writing Book that has been placed down.',
  'Spirit Box': 'Hear a reply on a Spirit Box after asking the ghost a question.',
};

const ghosts = [
  { name: 'Aswang', evidence: ['D.O.T.S Projector', 'Freezing Temperatures', 'Ghost Writing'] },
  { name: 'Banshee', evidence: ['D.O.T.S Projector', 'Ghost Orb', 'Ultraviolet'] },
  { name: 'Dayan', evidence: ['EMF Level 5', 'Ghost Orb', 'Spirit Box'] },
  { name: 'Deildegast', evidence: ['D.O.T.S Projector', 'EMF Level 5', 'Ghost Writing'] },
  { name: 'Demon', evidence: ['Ghost Writing', 'Ultraviolet', 'Freezing Temperatures'] },
  { name: 'Deogen', evidence: ['D.O.T.S Projector', 'Ghost Writing', 'Spirit Box'] },
  { name: 'Gallu', evidence: ['EMF Level 5', 'Spirit Box', 'Ultraviolet'] },
  { name: 'Goryo', evidence: ['D.O.T.S Projector', 'EMF Level 5', 'Ultraviolet'] },
  { name: 'Hantu', evidence: ['Ghost Orb', 'Ultraviolet', 'Freezing Temperatures'] },
  { name: 'Jinn', evidence: ['EMF Level 5', 'Ultraviolet', 'Freezing Temperatures'] },
  { name: 'Kormos', evidence: ['Ghost Orb', 'Spirit Box', 'Ultraviolet'] },
  { name: 'Mare', evidence: ['Ghost Writing', 'Ghost Orb', 'Spirit Box'] },
  { name: 'Moroi', evidence: ['Ghost Writing', 'Freezing Temperatures', 'Spirit Box'] },
  { name: 'Myling', evidence: ['Ghost Writing', 'EMF Level 5', 'Ultraviolet'] },
  { name: 'Obambo', evidence: ['D.O.T.S Projector', 'Ghost Writing', 'Ultraviolet'] },
  { name: 'Obake', evidence: ['EMF Level 5', 'Ghost Orb', 'Ultraviolet'] },
  { name: 'Oni', evidence: ['D.O.T.S Projector', 'EMF Level 5', 'Freezing Temperatures'] },
  { name: 'Onryo', evidence: ['Ghost Orb', 'Freezing Temperatures', 'Spirit Box'] },
  { name: 'Phantom', evidence: ['D.O.T.S Projector', 'Spirit Box', 'Ultraviolet'] },
  { name: 'Poltergeist', evidence: ['Ghost Writing', 'Spirit Box', 'Ultraviolet'] },
  { name: 'Raiju', evidence: ['D.O.T.S Projector', 'EMF Level 5', 'Ghost Orb'] },
  { name: 'Revenant', evidence: ['Ghost Writing', 'Ghost Orb', 'Freezing Temperatures'] },
  { name: 'Shade', evidence: ['Ghost Writing', 'EMF Level 5', 'Freezing Temperatures'] },
  { name: 'Spirit', evidence: ['Ghost Writing', 'EMF Level 5', 'Spirit Box'] },
  { name: 'Thaye', evidence: ['D.O.T.S Projector', 'Ghost Writing', 'Ghost Orb'] },
  { name: 'The Mimic', evidence: ['Spirit Box', 'Ultraviolet', 'Freezing Temperatures'], alwaysEvidence: ['Ghost Orb'], note: 'Ghost Orb (always present)' },
  { name: 'The Twins', evidence: ['EMF Level 5', 'Freezing Temperatures', 'Spirit Box'] },
  { name: 'Wraith', evidence: ['D.O.T.S Projector', 'EMF Level 5', 'Spirit Box'] },
  { name: 'Yokai', evidence: ['D.O.T.S Projector', 'Ghost Orb', 'Spirit Box'] },
  { name: 'Yurei', evidence: ['D.O.T.S Projector', 'Ghost Orb', 'Freezing Temperatures'] },
];

const ghostProfiles = {
  Aswang: { strengths: 'Accelerates unusually fast once it gets line of sight on a target.', weaknesses: 'Base hunt speed (~1.53 m/s) is slower than the 1.7 m/s standard, and it cannot kill a player properly hidden in an official hiding spot â€” reaching them ends the hunt instead.' },
  Banshee: { strengths: 'Targets one chosen player and is more likely to perform singing events.', weaknesses: 'Its distinctive parabolic microphone wails can reveal its identity.' },
  Dayan: { strengths: 'Speeds up to ~2.25 m/s and its hunt threshold rises toward 65% when a nearby player moves.', weaknesses: 'Slows to ~1.2 m/s and needs sanity near 45% to hunt when a nearby player stands still (1.7 m/s if nobody is within 10m); always identifies as female.' },
  Deildegast: { strengths: 'Can hunt at up to ~3.0 m/s on a fresh contract, before anything has been disturbed.', weaknesses: 'Slows by about 0.1 m/s for every unique object investigators move or interact with since the last hunt attempt (up to 26), eventually crawling at ~0.4 m/s; its speed is fixed for the hunt and gains no line-of-sight acceleration.' },
  Demon: { strengths: 'Can hunt at unusually low sanity; incense prevents its hunts for less time.', weaknesses: 'Crucifix protection has a larger effective range against it.' },
  Deogen: { strengths: 'Always knows where players are and moves very quickly toward them during a hunt.', weaknesses: 'Becomes extremely slow once close to its target.' },
  Gallu: { strengths: 'Becomes enraged (~1.955 m/s, 60% hunt threshold) when incense, a crucifix or salt is used against it.', weaknesses: 'Can also become weakened (~1.36 m/s, 40% hunt threshold), its slowest and least aggressive state; normal state is 1.7 m/s at a 50% threshold.' },
  Goryo: { strengths: 'Can produce D.O.T.S evidence even when no player is in its room.', weaknesses: 'That silhouette only appears while the room is empty, and can only be seen through a Video Camera.' },
  Hantu: { strengths: 'Moves faster in colder areas and produces freezing breath when the fuse box is off.', weaknesses: 'Warmer areas slow it down and it never turns the fuse box on.' },
  Jinn: { strengths: 'Moves faster with distant line of sight while the fuse box is on.', weaknesses: 'Cannot use its ability with the fuse box off and never turns it off directly.' },
  Kormos: { strengths: 'Detects crouch-walking, walking and sprinting at progressively longer ranges, and sprinting nearby can raise its hunt threshold to ~70%.', weaknesses: 'Essentially blind during hunts â€” it relies almost entirely on sound, so staying quiet and still is very effective.' },
  Mare: { strengths: 'Has a higher hunt threshold in darkness and may turn lights off immediately.', weaknesses: 'Has a lower hunt threshold in light and never turns lights on.' },
  Moroi: { strengths: 'Moves faster as average sanity falls and can curse players with faster sanity drain.', weaknesses: 'Incense blinds it for longer during hunts.' },
  Myling: { strengths: 'Produces paranormal sounds more frequently on the Parabolic Microphone.', weaknesses: 'Its hunt sounds are audible only at closer range.' },
  Obambo: { strengths: 'Its aggressive state (~1.955 m/s, 65% hunt threshold) hunts sooner and moves faster, and an aggressive-start hunt is also shorter.', weaknesses: 'Its calm state (~1.445 m/s, 10% hunt threshold) moves slowly and rarely hunts.' },
  Obake: { strengths: 'Can leave special fingerprints and may briefly shapeshift during a hunt.', weaknesses: 'May fail to leave fingerprints and existing prints can disappear sooner.' },
  Oni: { strengths: 'Becomes more active near players and is more visible during hunts.', weaknesses: 'Cannot perform the airball event.' },
  Onryo: { strengths: 'May hunt after extinguishing three flames regardless of sanity.', weaknesses: 'A nearby lit flame can prevent its hunt.' },
  Phantom: { strengths: 'May walk to a random player and disappears when photographed.', weaknesses: 'Looking at it drains sanity and it is less visible during hunts.' },
  Poltergeist: { strengths: 'Can throw several objects at once and at high velocity.', weaknesses: 'Becomes powerless when few throwables are nearby.' },
  Raiju: { strengths: 'Moves faster near active electronics and disrupts equipment from farther away.', weaknesses: 'Its speed advantage depends on nearby active electronics.' },
  Revenant: { strengths: 'Moves very quickly after detecting a player during a hunt.', weaknesses: 'Moves very slowly when it cannot detect anyone.' },
  Shade: { strengths: 'Is less likely to perform interactions, making it harder to provoke.', weaknesses: 'Cannot hunt while people are nearby.' },
  Spirit: { strengths: 'Has no special strength.', weaknesses: 'Incense prevents its hunts for longer than usual.' },
  Thaye: { strengths: 'Starts very active and fast.', weaknesses: 'Becomes slower and less active as it ages near players.' },
  'The Mimic': { strengths: 'Can copy other ghosts abilities and traits.', weaknesses: 'Always produces fake Ghost Orbs as secondary evidence.' },
  'The Twins': { strengths: 'Either twin can begin a hunt, with one twin being fast.', weaknesses: 'The other twin is slow and the pair often interacts in different places.' },
  Wraith: { strengths: 'May teleport to a random player and cannot be tracked by footsteps.', weaknesses: 'Will not step in salt.' },
  Yokai: { strengths: 'Talking near it can raise its hunt threshold.', weaknesses: 'During a hunt it can only hear players within a short radius.' },
  Yurei: { strengths: 'Can drain sanity quickly and slam doors with its ability.', weaknesses: 'Smudging it temporarily traps it and reduces wandering.' },
};

const ghostLore = {
  Aswang: 'A restless presence that closes distance with unnatural speed once it has a clear line of sight.',
  Banshee: 'The singing siren, known for attracting its victims through song and singling out its prey before a killing blow.',
  Dayan: 'A watchful entity whose temper changes depending on whether the investigator moves or remains still.',
  Deildegast: 'An old spirit that arrives with frightening urgency, then loses momentum as the house is disturbed.',
  Demon: 'A violent and persistent ghost with a reputation for beginning its attacks long before the team feels ready.',
  Deogen: 'A relentless hunter that always knows where you are, no matter how carefully you try to hide.',
  Gallu: 'A volatile spirit whose aggression rises when investigators rely too heavily on protective equipment.',
  Goryo: 'A private apparition that reveals its D.O.T.S. silhouette only when the room has been left undisturbed.',
  Hantu: 'A cold-bound presence that thrives when the building is left dark and unheated.',
  Jinn: 'A territorial spirit tied to the electrical system and capable of crossing a room in a sudden rush.',
  Kormos: 'A patient stalker that listens for hurried footsteps long before it can properly see its prey.',
  Mare: 'A nocturnal presence that grows bolder in darkness and resents every light brought back into the room.',
  Moroi: 'A curse-bearing ghost that grows more dangerous as the investigators lose their composure.',
  Myling: 'A quiet presence whose warnings arrive through distant sounds before its hunt draws close.',
  Obambo: 'A changeable entity that shifts between calm and aggression as the investigation unfolds.',
  Obake: 'A deceptive shape-shifter that leaves an unreliable trace and may briefly wear another form.',
  Oni: 'A highly active apparition that becomes difficult to ignore when investigators crowd its territory.',
  Onryo: 'A flame-haunted spirit whose patience can end after too many nearby candles are extinguished.',
  Phantom: 'A distant apparition that steals attention, sanity, and sometimes the confidence of the person it follows.',
  Poltergeist: 'A disruptive force that turns an ordinary room into a storm of thrown objects.',
  Raiju: 'An electronic predator drawn to the equipment investigators carry into its territory.',
  Revenant: 'A slow-moving presence until it finds someone, at which point the hunt becomes terrifyingly fast.',
  Shade: 'A withdrawn ghost that prefers silence and becomes reluctant to act when people gather nearby.',
  Spirit: 'A common but unpredictable haunting with no defining strength beyond the evidence it leaves behind.',
  Thaye: 'A young and energetic presence that gradually weakens as it spends time around living investigators.',
  'The Mimic': 'An imitation with no fixed personality, borrowing the habits and dangers of other ghost types.',
  'The Twins': 'Two voices in one haunting, creating a pattern of activity that seems to come from opposite ends of the house.',
  Wraith: 'A wandering apparition that ignores the ordinary traces left by other ghosts.',
  Yokai: 'A responsive spirit that listens closely when investigators speak near its room.',
  Yurei: 'A sorrowful presence that presses its weight onto the living and leaves doors disturbed in its wake.',
};

// Comparable hunt-speed profiles on a 1-5 scale:
// 1 very slow | 2 slow | 3 standard (1.7 m/s) | 4 fast | 5 very fast.
// min/max describe the range a ghost can cover; equal values mean a fixed speed.
const ghostSpeeds = {
  Aswang: { min: 2, max: 5, note: 'Base speed ~1.53 m/s (slower than the 1.7 m/s standard), but accelerates unusually fast once it has line of sight. Cannot kill a player hidden in an official hiding spot â€” reaching them ends the hunt.' },
  Banshee: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Dayan: { min: 2, max: 5, note: '1.2 m/s if the nearest player stands still, 2.25 m/s if they move, 1.7 m/s if nobody is within 10m. Hunt threshold shifts between 45% and 65% to match. Always female.' },
  Deildegast: { min: 1, max: 5, note: 'Roughly 3.0 m/s down to 0.4 m/s. Each unique object moved/interacted with since the last hunt attempt cuts ~0.1 m/s off its next hunt speed (up to 26 interactions). Speed is fixed once the hunt starts â€” no line-of-sight acceleration.' },
  Demon: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Deogen: { min: 1, max: 5, note: 'Very fast from far away, extremely slow once close.' },
  Gallu: { min: 2, max: 4, note: 'Cycles between normal (1.7 m/s, 50% threshold), enraged (1.955 m/s, 60% threshold) and weakened (1.36 m/s, 40% threshold) states. Incense, crucifixes and salt can trigger a state change.' },
  Goryo: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Hantu: { min: 2, max: 5, note: 'Slow in warm rooms, very fast in freezing air.' },
  Jinn: { min: 3, max: 4, note: 'Fast during distant line of sight while the fuse box is on.' },
  Kormos: { min: 3, max: 3, note: 'Standard 1.7 m/s hunt speed, but effectively blind â€” it hunts by sound, detecting crouch-walking, walking and sprinting at progressively longer ranges. Sprinting nearby can raise its hunt threshold to ~70%.' },
  Mare: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Moroi: { min: 3, max: 5, note: 'Speed climbs as team sanity falls.' },
  Myling: { min: 3, max: 3, note: 'Standard hunt speed, but footsteps stay quiet.' },
  Obambo: { min: 2, max: 4, note: 'Alternates calm (1.445 m/s, 10% hunt threshold) and aggressive (1.955 m/s, 65% hunt threshold) states; an aggressive-start hunt is also shorter.' },
  Obake: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Oni: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Onryo: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Phantom: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Poltergeist: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Raiju: { min: 3, max: 4, note: 'Fast near active electronics.' },
  Revenant: { min: 1, max: 5, note: 'Crawls while roaming, sprints once it spots you.' },
  Shade: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Spirit: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Thaye: { min: 2, max: 5, note: 'Blistering when young, slows as it ages.' },
  'The Mimic': { min: 3, max: 3, note: 'Matches whatever ghost it is copying.' },
  'The Twins': { min: 2, max: 3, note: 'One twin slow, the other slightly fast.' },
  Wraith: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Yokai: { min: 3, max: 3, note: 'Standard hunt speed.' },
  Yurei: { min: 3, max: 3, note: 'Standard hunt speed.' },
};

// Sanity % at/below which a ghost can start a hunt. Most ghosts use the
// standard 50% baseline; a handful shift depending on their state/behavior.
const ghostHuntThresholds = {
  Dayan: '45%\u201365% (rises when a nearby player moves)',
  Gallu: '40%\u201360% (40% weakened / 50% normal / 60% enraged)',
  Kormos: '50%, up to ~70% when a player sprints nearby',
  Obambo: '10%\u201365% (10% calm / 65% aggressive)',
  'The Mimic': 'Matches whatever ghost it is copying',
};

function huntThreshold(name) {
  return ghostHuntThresholds[name] || '50% (standard)';
}

// Practical, non-evidence tells observed during play. Each either rules out
// specific ghosts or, if only one ghost can produce it, identifies that ghost.
const behaviorClues = [
  {
    id: 'saltFootprints',
    label: 'Footprints appear in salt',
    description: 'The ghost walked through a salt pile and left visible footprints.',
    rulesOut: ['Wraith'],
  },
  {
    id: 'breakerOn',
    label: 'Ghost turns the breaker back on',
    description: 'The ghost interacted with the fuse box to switch the power on by itself.',
    rulesOut: ['Hantu'],
  },
  {
    id: 'dotsNoCamera',
    label: 'D.O.T.S. silhouette seen without a Video Camera',
    description: 'You saw the ghost model directly in the D.O.T.S. beams, not through a camera feed.',
    rulesOut: ['Goryo'],
  },
  {
    id: 'breathFog',
    label: 'Visible breath fog from the ghost',
    description: 'Freezing breath fog is visible around the ghost while the fuse box is off.',
    onlyGhost: 'Hantu',
  },
  {
    id: 'writingNoBook',
    label: 'Writing appears without a Ghost Writing Book',
    description: 'A message appears (e.g. on a mirror or wall) with no Ghost Writing Book placed down.',
    onlyGhost: 'Demon',
  },
  {
    id: 'onryoThirdFlame',
    label: 'Hunt starts right after a third flame is blown out',
    description: 'A hunt begins immediately after extinguishing a third candle/flame, even well above 50% sanity.',
    onlyGhost: 'Onryo',
  },
  {
    id: 'mareInstantDark',
    label: 'Lights switch off the instant someone enters a room',
    description: 'A room goes dark the moment an investigator walks in, without anyone touching a switch.',
    onlyGhost: 'Mare',
  },
  {
    id: 'raijuFarStatic',
    label: 'Electronics glitch or static from unusually far away',
    description: 'Devices spike, flicker or static well outside the ghost\'s normal interaction range.',
    onlyGhost: 'Raiju',
  },
  {
    id: 'revenantSuddenSprint',
    label: 'Ghost creeps slowly, then suddenly sprints once it spots you',
    description: 'During a hunt it roams at a crawl until it detects a player, then rushes at high speed.',
    onlyGhost: 'Revenant',
  },
  {
    id: 'yokaiShortHearing',
    label: 'Ghost seems deaf beyond a short range during a hunt',
    description: 'Talking or making noise from normal distance during a hunt does not seem to draw it in.',
    onlyGhost: 'Yokai',
  },
];

function matchesClues(ghost) {
  const active = [...state.checkedClues].map((id) => behaviorClues.find((clue) => clue.id === id));
  const isExcluded = active.some((clue) => clue.rulesOut?.includes(ghost.name));
  const requiredGhosts = active.filter((clue) => clue.onlyGhost).map((clue) => clue.onlyGhost);
  const failsRequired = requiredGhosts.length > 0 && !requiredGhosts.every((name) => name === ghost.name);
  return !isExcluded && !failsRequired;
}

function isPossible(ghost) {
  return matchesEvidence(ghost) && matchesClues(ghost) && !state.excludedGhosts.has(ghost.name);
}

function speedTier(speed) {
  if (speed.max >= 5) return 'very-fast';
  if (speed.max === 4) return 'fast';
  if (speed.max <= 2) return 'slow';
  return 'standard';
}

function speedLabel(speed) {
  if (speed.min !== speed.max) return 'Variable';
  return ['', 'Very slow', 'Slow', 'Standard', 'Fast', 'Very fast'][speed.max];
}

function renderSpeedMeter(speed) {
  const point = (v) => ((v - 1) / 4) * 100;
  const isFixed = speed.min === speed.max;
  const width = isFixed ? 12 : point(speed.max) - point(speed.min);
  const left = isFixed ? Math.min(Math.max(point(speed.min) - 6, 0), 88) : point(speed.min);
  const tier = speedTier(speed);

  return `
    <div class="speed-meter" title="${speed.note}">
      <span class="speed-meter__track">
        <span class="speed-meter__range speed-meter__range--${tier}" style="left:${left}%;width:${width}%"></span>
      </span>
      <small class="speed-meter__label">${speedLabel(speed)}</small>
    </div>
  `;
}

const state = {
  checkedEvidence: new Set(),
  ruledOutEvidence: new Set(),
  checkedClues: new Set(),
  notObservedClues: new Set(),
  excludedGhosts: new Set(),
  hideRuledOut: false,
};

const STORAGE_KEY = 'ezPhasmoCompanion.state.v1';

function saveState() {
  const data = {
    checkedEvidence: [...state.checkedEvidence],
    ruledOutEvidence: [...state.ruledOutEvidence],
    checkedClues: [...state.checkedClues],
    notObservedClues: [...state.notObservedClues],
    excludedGhosts: [...state.excludedGhosts],
    hideRuledOut: state.hideRuledOut,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Storage may be unavailable (e.g. private browsing); skip silently.
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const data = JSON.parse(raw);
    state.checkedEvidence = new Set(data.checkedEvidence || []);
    state.ruledOutEvidence = new Set(data.ruledOutEvidence || []);
    state.checkedClues = new Set(data.checkedClues || []);
    state.notObservedClues = new Set(data.notObservedClues || []);
    state.excludedGhosts = new Set(data.excludedGhosts || []);
    state.hideRuledOut = true;
  } catch {
    // Ignore corrupt/unavailable storage and start fresh.
  }
}

const evidenceList = document.querySelector('#evidenceList');
const cluesList = document.querySelector('#cluesList');
const ghostGrid = document.querySelector('#ghostGrid');
const resetBtn = document.querySelector('#resetBtn');
const possibleCount = document.querySelector('#possibleCount');
const masterGridBtn = document.querySelector('#masterGridBtn');
const masterGrid = document.querySelector('#masterGrid');
const masterGridBody = document.querySelector('#masterGridBody');
const closeMasterGrid = document.querySelector('#closeMasterGrid');
const ghostDetails = document.querySelector('#ghostDetails');
const closeDetails = document.querySelector('#closeDetails');
const detailsName = document.querySelector('#detailsName');
const detailsLore = document.querySelector('#detailsLore');
const detailsStatus = document.querySelector('#detailsStatus');
const detailsEvidence = document.querySelector('#detailsEvidence');
const detailsStrengths = document.querySelector('#detailsStrengths');
const detailsWeaknesses = document.querySelector('#detailsWeaknesses');
const detailsSpecial = document.querySelector('#detailsSpecial');
const detailsPage = document.querySelector('#detailsPage');
const aboutBtn = document.querySelector('#aboutBtn');
const aboutDialog = document.querySelector('#aboutDialog');
const closeAbout = document.querySelector('#closeAbout');
const hideRuledOutBtn = document.querySelector('#hideRuledOutBtn');
const detailsSpeed = document.querySelector('#detailsSpeed');
const detailsThreshold = document.querySelector('#detailsThreshold');
const evidenceWarning = document.querySelector('#evidenceWarning');

const sortState = { key: null, dir: 1 };

function matchesEvidence(ghost) {
  const hasEvidence = (item) =>
    ghost.evidence.includes(item) || ghost.alwaysEvidence?.includes(item);

  // Ruled-out evidence immediately disqualifies any ghost that would show it.
  const showsRuledOut = (item) =>
    ghost.evidence.includes(item) || ghost.alwaysEvidence?.includes(item);

  const allFoundPresent = [...state.checkedEvidence].every(hasEvidence);
  const noneRuledOutPresent = ![...state.ruledOutEvidence].some(showsRuledOut);

  return allFoundPresent && noneRuledOutPresent;
}

function renderEvidence() {
  const foundCount = state.checkedEvidence.size;
  evidenceWarning.hidden = foundCount <= 3;
  evidenceWarning.textContent =
    foundCount > 3
      ? `${foundCount} evidence marked as found, but every ghost has only 3 â€” double-check your log.`
      : '';

  evidenceList.innerHTML = evidenceOptions
    .map((item) => {
      const isFound = state.checkedEvidence.has(item);
      const isRuledOut = state.ruledOutEvidence.has(item);
      const stateClass = isRuledOut ? 'evidence-item--ruled-out' : isFound ? 'evidence-item--found' : '';

      return `
        <div class="evidence-item ${stateClass}">
          <label>
            <input type="checkbox" value="${item}" ${isFound ? 'checked' : ''} data-ruled-out="${isRuledOut}" />
            <span class="evidence-copy">
              <strong>${item}</strong>
              <small>${evidenceDescriptions[item]}</small>
            </span>
            <span class="evidence-state-label">${isRuledOut ? 'Ruled out' : isFound ? 'Found' : ''}</span>
          </label>
        </div>
      `;
    })
    .join('');

  // Tri-state cycle: unmarked -> found -> ruled out -> unmarked.
  // Handler lives on the label (not the checkbox) because a click on a checkbox
  // nested inside a label fires twice: the real click plus the label's
  // synthetic activation click. preventDefault stops the checkbox toggling.
  evidenceList.querySelectorAll('.evidence-item label').forEach((label) => {
    label.addEventListener('click', (event) => {
      event.preventDefault();
      const { value } = label.querySelector('input');

      if (state.checkedEvidence.has(value)) {
        // found -> ruled out
        state.checkedEvidence.delete(value);
        state.ruledOutEvidence.add(value);
      } else if (state.ruledOutEvidence.has(value)) {
        // ruled out -> unmarked
        state.ruledOutEvidence.delete(value);
      } else {
        // unmarked -> found
        state.checkedEvidence.add(value);
      }

      render();
    });
  });
}

function renderClues() {
  cluesList.innerHTML = behaviorClues
    .map((clue) => {
      const isObserved = state.checkedClues.has(clue.id);
      const isNotObserved = state.notObservedClues.has(clue.id);
      const stateClass = isObserved ? 'evidence-item--found' : isNotObserved ? 'evidence-item--ruled-out' : '';

      return `
        <div class="evidence-item ${stateClass}">
          <label>
            <input type="checkbox" value="${clue.id}" ${isObserved ? 'checked' : ''} data-not-observed="${isNotObserved}" />
            <span class="evidence-copy">
              <strong>${clue.label}</strong>
              <small>${clue.description}</small>
            </span>
            <span class="evidence-state-label">${isObserved ? 'Observed' : isNotObserved ? 'Not seen' : ''}</span>
          </label>
        </div>
      `;
    })
    .join('');

  // Tri-state cycle: unmarked -> observed -> not seen -> unmarked.
  // "Not seen" is informational only (a missed behavioral tell doesn't rule
  // a ghost out the way missing core evidence does) and doesn't affect matching.
  cluesList.querySelectorAll('.evidence-item label').forEach((label) => {
    label.addEventListener('click', (event) => {
      event.preventDefault();
      const { value } = label.querySelector('input');

      if (state.checkedClues.has(value)) {
        state.checkedClues.delete(value);
        state.notObservedClues.add(value);
      } else if (state.notObservedClues.has(value)) {
        state.notObservedClues.delete(value);
      } else {
        state.checkedClues.add(value);
      }

      render();
    });
  });
}

function renderPossibleGhosts() {
  possibleCount.textContent = ghosts.filter((ghost) => isPossible(ghost)).length;
}

function renderGhostGrid() {
  const possible = ghosts.filter((ghost) => isPossible(ghost));
  const soleCandidate = possible.length === 1;
  const visibleGhosts = ghosts.filter((ghost) => {
    return state.hideRuledOut ? isPossible(ghost) : true;
  });

  ghostGrid.className = `ghost-grid ${soleCandidate ? 'has-sole-candidate' : ''}`;

  ghostGrid.innerHTML = visibleGhosts
    .map((ghost) => {
      const matched = isPossible(ghost);

      return `
        <article class="ghost-card ${!matched ? 'disqualified' : ''} ${soleCandidate ? 'sole-candidate' : ''}" data-name="${ghost.name}" tabindex="0" role="button" aria-label="View details for ${ghost.name}">
          <div class="ghost-card__header">
            <h3>${ghost.name}${soleCandidate && matched ? '<span class="candidate-check" aria-label="Only remaining candidate">&#10003;</span>' : ''}</h3>
            <button type="button" class="ghost-exclude-btn" data-exclude-ghost="${ghost.name}" aria-label="${state.excludedGhosts.has(ghost.name) ? 'Restore' : 'Exclude'} ${ghost.name}" title="${state.excludedGhosts.has(ghost.name) ? 'Restore ghost' : 'Exclude ghost'}">${state.excludedGhosts.has(ghost.name) ? 'Restore' : 'X'}</button>
          </div>

          <div class="ghost-card__meta">
            <span>Evidence</span>
            <span>${soleCandidate && matched ? 'Confirmed' : matched ? 'Possible' : 'No'}</span>
          </div>

          <div class="ghost-card__meta ghost-card__meta--speed">
            <span>Hunt speed</span>
            <span class="speed-tag speed-tag--${speedTier(ghostSpeeds[ghost.name])}">${speedLabel(ghostSpeeds[ghost.name])}</span>
          </div>

          <div class="ghost-card__meta">
            <span>Hunt sanity</span>
            <span class="speed-tag">${huntThreshold(ghost.name)}</span>
          </div>

          <div class="badge-list">
            ${ghost.evidence
              .map((item) => {
                const isChecked = state.checkedEvidence.has(item);
                const isRuledOut = state.ruledOutEvidence.has(item);
                const cls = isChecked ? 'matched' : isRuledOut ? 'ruled-out' : '';
                return `<span class="badge ${cls}">${item}</span>`;
              })
              .join('')}
            ${ghost.note ? `<span class="badge badge--note">${ghost.note}</span>` : ''}
          </div>
        </article>
      `;
    })
    .join('');

  ghostGrid.querySelectorAll('.ghost-card').forEach((card) => {
    const excludeBtn = card.querySelector('.ghost-exclude-btn');
    excludeBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      const ghostName = card.dataset.name;
      if (state.excludedGhosts.has(ghostName)) {
        state.excludedGhosts.delete(ghostName);
      } else {
        state.excludedGhosts.add(ghostName);
      }
      render();
    });
    const openDetails = () => showGhostDetails(card.dataset.name);
    card.addEventListener('click', (event) => {
      if (!event.target.closest('.ghost-exclude-btn')) openDetails();
    });
    card.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        openDetails();
      }
    });
  });
}


function renderMasterGrid() {
  const possible = ghosts.filter((ghost) => isPossible(ghost));

  let rows = ghosts.filter((ghost) => !state.hideRuledOut || isPossible(ghost));

  if (sortState.key === 'name') {
    rows = [...rows].sort((a, b) => sortState.dir * a.name.localeCompare(b.name));
  } else if (sortState.key === 'speed') {
    rows = [...rows].sort((a, b) => {
      const speedA = ghostSpeeds[a.name].min + ghostSpeeds[a.name].max;
      const speedB = ghostSpeeds[b.name].min + ghostSpeeds[b.name].max;
      return sortState.dir * (speedB - speedA);
    });
  }

  masterGridBody.innerHTML = rows
    .map((ghost) => {
      const matched = isPossible(ghost);
      const status = matched ? possible.length === 1 ? 'Confirmed' : 'Possible' : 'Ruled out';
      const statusClass = status.toLowerCase().replace(' ', '-');

      return `
        <tr class="master-row master-row--${statusClass}" data-name="${ghost.name}">
          <th scope="row">${ghost.name}</th>
          <td>${renderSpeedMeter(ghostSpeeds[ghost.name])}</td>
          <td>${huntThreshold(ghost.name)}</td>
          <td><div class="master-evidence">${ghost.evidence.map((item) => `<span>${item}</span>`).join('')}</div>${ghost.note ? `<small class="master-note">${ghost.note}</small>` : ''}</td>
          <td>${ghostProfiles[ghost.name].strengths}</td>
          <td>${ghostProfiles[ghost.name].weaknesses}</td>
          <td><span class="master-status">${status}</span></td>
        </tr>
      `;
    })
    .join('');

  updateSortArrows();
}

function updateSortArrows() {
  document.querySelectorAll('.master-grid th.sortable').forEach((th) => {
    const arrow = th.querySelector('.sort-arrow');
    if (!arrow) return;
    if (sortState.key !== th.dataset.sort) {
      arrow.textContent = '';
    } else {
      const descending = th.dataset.sort === 'speed' ? sortState.dir === 1 : sortState.dir === -1;
      arrow.textContent = descending ? '\u25BC' : '\u25B2';
    }
  });
}

function showGhostDetails(ghostName) {
  const ghost = ghosts.find((item) => item.name === ghostName);
  if (!ghost) return;

  const matched = isPossible(ghost);
  const possible = ghosts.filter((item) => isPossible(item));
  const status = !matched ? 'Disqualified' : possible.length === 1 ? 'Confirmed' : 'Possible';

  detailsName.textContent = ghost.name;
  detailsLore.textContent = ghostLore[ghost.name];
  detailsStatus.textContent = status;
  detailsStatus.className = `details-status details-status--${status.toLowerCase()}`;
  detailsEvidence.innerHTML = ghost.evidence
    .map((item) => {
      const isChecked = state.checkedEvidence.has(item);
      const isRuledOut = state.ruledOutEvidence.has(item);
      const cls = isChecked ? 'matched' : isRuledOut ? 'ruled-out' : '';
      return `<span class="badge ${cls}">${item}</span>`;
    })
    .join('');
  const speed = ghostSpeeds[ghost.name];
  detailsSpeed.innerHTML = `${renderSpeedMeter(speed)}<p class="speed-note">${speed.note}</p>`;
  detailsThreshold.textContent = huntThreshold(ghost.name);
  detailsStrengths.textContent = ghostProfiles[ghost.name].strengths;
  detailsWeaknesses.textContent = ghostProfiles[ghost.name].weaknesses;
  detailsSpecial.textContent = ghost.note || '';
  detailsPage.textContent = `Journal page ${ghosts.indexOf(ghost) + 27}`;
  ghostDetails.showModal();
}

function render() {
  renderEvidence();
  renderClues();
  renderPossibleGhosts();
  renderGhostGrid();
  renderMasterGrid();
  saveState();
}


function updateHideRuledOutButton() {
  hideRuledOutBtn.setAttribute(
    'aria-pressed',
    String(state.hideRuledOut)
  );

  hideRuledOutBtn.textContent =
    state.hideRuledOut
      ? 'HIDING RULED OUT'
      : 'SHOWING RULED OUT';
}
masterGridBtn.addEventListener('click', () => {
  masterGrid.showModal();
  masterGridBtn.setAttribute('aria-pressed', 'true');
});

hideRuledOutBtn.addEventListener('click', () => {
  state.hideRuledOut = !state.hideRuledOut;

  updateHideRuledOutButton();

  renderGhostGrid();
  renderMasterGrid();
  saveState();
});

closeMasterGrid.addEventListener('click', () => {
  masterGrid.close();
  masterGridBtn.setAttribute('aria-pressed', 'false');
});

masterGrid.addEventListener('click', (event) => {
  if (event.target === masterGrid) {
    masterGrid.close();
    masterGridBtn.setAttribute('aria-pressed', 'false');
  }
});

document.querySelectorAll('.master-grid th.sortable').forEach((th) => {
  th.addEventListener('click', () => {
    const key = th.dataset.sort;
    if (sortState.key === key) {
      sortState.dir *= -1;
    } else {
      sortState.key = key;
      sortState.dir = 1;
    }
    renderMasterGrid();
  });
});

resetBtn.addEventListener('click', () => {
  state.checkedEvidence.clear();
  state.ruledOutEvidence.clear();
  state.checkedClues.clear();
  state.notObservedClues.clear();
  state.excludedGhosts.clear();
  render();
});

closeDetails.addEventListener('click', () => ghostDetails.close());
ghostDetails.addEventListener('click', (event) => {
  if (event.target === ghostDetails) ghostDetails.close();
});

aboutBtn.addEventListener('click', () => aboutDialog.showModal());
closeAbout.addEventListener('click', () => aboutDialog.close());
aboutDialog.addEventListener('click', (event) => {
  if (event.target === aboutDialog) aboutDialog.close();
});

loadState();

// START WITH A FRESH INVESTIGATION
// Preserve interface preferences, but never restore evidence or clues
// from the previous investigation when the application launches.
state.checkedEvidence.clear();
state.ruledOutEvidence.clear();
state.checkedClues.clear();
state.notObservedClues.clear();
state.excludedGhosts.clear();

// Store the clean investigation state.
saveState();
hideRuledOutBtn.setAttribute('aria-pressed', String(state.hideRuledOut));


render();
